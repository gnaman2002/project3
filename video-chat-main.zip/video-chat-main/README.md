# Chat-Room
A video conferencing application made with sockets using python 3.

To host:-
python3 serverMedia.py

To connect:-
python3 clientMedia.py

Currently in development...
