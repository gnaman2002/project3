# Car-Price-Prediction-by-Regression
it predict car price based on car name ,age ,owner type,and car type
